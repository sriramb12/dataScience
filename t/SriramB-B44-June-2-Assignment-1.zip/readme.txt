assignment :1
Date of assignment: 2 June 2018
Submitter: sriram bhamidipati
Batch 44


Attached :
1. asgmt.1-2june.R
2. assignment-output.txt

Instructionsn:
Unzip the file asgmt.1-2june.R.zip
Rscript  asgmt.1-2june.R


Tested using Rscript on macos

