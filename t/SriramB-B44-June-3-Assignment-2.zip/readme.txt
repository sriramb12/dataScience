assignment :2
Date of assignment: 3 June 2018
Submitter: sriram bhamidipati
Batch 44

Status: Incomplete 

Attached :
1. asgmt.2-3june.R
2. output.txt

Instructionsn:
Unzip the file asgmt.1-2june.R.zip
Rscript  asgmt.2-3june.R


Tested using Rscript on macos
